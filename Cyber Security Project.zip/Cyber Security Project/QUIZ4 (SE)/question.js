var questions = [{
    num: 1,
    question: "___________ is a special form of attack using which hackers’ exploit – human psychology.",
    answer: "Social Engineering.",
    options: [
        "Cross Site Scripting.",
      "Insecure network.",
      "Social Engineering.",
      "Reverse Engineering."
    ]
  },
  {
    num: 2,
    question: "Which of the following do not comes under Social Engineering?",
    answer: "Spamming.",
    options: [
      "Tailgating",
      "Phishing.",
      "Pretexting.",
      "Spamming."
    ]
  },
  {
    num: 3,
    question: "Which of the following is the technique used to look for information in trash or around dustbin container?",
    answer: "Dumpster diving.",
    options: [
      "Pretexting.",
      "Quid Pro Quo.",
      "Dumpster diving.",
      "Baiting",
    ]
  },
];