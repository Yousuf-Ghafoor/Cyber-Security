var questions = [{
    num: 1,
    question: "If you fall for a phishing scam, what should you do to limit the damage?",
    answer: "Change any compromised passwords.",
    options: [
        "Change any compromised passwords.",
      "Delete the phishing email.",
      "Unplug the computer. This will get rid of any malware.",
    ]
  },
  {
    num: 2,
    question: "Which of them is not a wireless attack?",
    answer: "Phishing",
    options: [
      "Eavesdropping",
      "MAC Spoofing",
      "Wireless Hijacking",
      "Phishing"
    ]
  },
  {
    num: 3,
    question: "Which of them is not an example of physical hacking?",
    answer: "Phishing",
    options: [
      "Walk-in using piggybacking",
      "Sneak-in",
      "Phishing",
      "Break-in and steal",
    ]
  },
];