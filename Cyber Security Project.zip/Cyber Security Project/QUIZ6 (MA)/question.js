var questions = [{
    num: 1,
    question: "The full form of Malware is ________",
    answer: "Malicious Software.",
    options: [
        "Malfunctioned Software.",
      "Multipurpose Software.",
      "Malicious Software.",
      "Malfunctioning of Security."
    ]
  },
  {
    num: 2,
    question: "Who deploy Malwares to a system or network?",
    answer: "Criminal organizations, Black hat hackers, malware developers, cyber-terrorists.",
    options: [
      "Criminal organizations, Black hat hackers, malware developers, cyber-terrorists.",
      "Criminal organizations, White hat hackers, malware developers, cyber-terrorists.",
      "Criminal organizations, Black hat hackers, software developers, cyber-terrorists.",
      "Criminal organizations, gray hat hackers, Malware developers, Penetration testers."
    ]
  },
  {
    num: 3,
    question: "Which of this is an example of physical hacking?",
    answer: "Inserting malware loaded USB to a system.",
    options: [
      "Remote Unauthorised access.",
      "Inserting malware loaded USB to a system.",
      "SQL Injection on SQL vulnerable site.",
      "DDoS (Distributed Denial of Service) attack.",
    ]
  },
];