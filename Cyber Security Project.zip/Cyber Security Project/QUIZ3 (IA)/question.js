var questions = [{
    num: 1,
    question: "Why are insider threats one of the most challenging attack vectors?",
    answer: "Employees are trusted users who have legitimate access to an organization’s data and resources.",
    options: [
        "Insider attacks are common, obvious, and overwhelm IT security.",
      "There is little that can be done to prevent a denial of service attack.",
      "Employees are trusted users who have legitimate access to an organization’s data and resources.",
      "Network security is designed to defend against outsiders, not insiders."
    ]
  },
  {
    num: 2,
    question: "What is the root cause of almost every data breach?",
    answer: "Human error.",
    options: [
      "Zero-day attack.",
      "Human error.",
      "Poorly crafted password.",
      "Unpatched device. "
    ]
  },
  {
    num: 3,
    question: "Who are included as insider threats? ",
    answer: "Employees who sometimes do not follow security practices.",
    options: [
      "Ambitious people.",
      "Another organization or person who see themselves as competitors.",
      "Any person with network security skills who works outside an organization.",
      "Employees who sometimes do not follow security practices.",
    ]
  },
];