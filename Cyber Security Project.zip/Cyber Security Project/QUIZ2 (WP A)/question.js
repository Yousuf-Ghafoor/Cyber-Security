var questions = [{
    num: 1,
    question: "Which one of the following statements about a password is TRUE?",
    answer: "It should be changed regularly.",
    options: [
        "It must be changed only if it is compromised.",
      "It cannot contain special character symbols.",
      "It must be registered with the system administrator.",
      "It should be changed regularly."
    ]
  },
  {
    num: 2,
    question: "How often do hacking 2-related data breaches leverage stolen or weak passwords? data ",
    answer: "81% of the time.",
    options: [
      "10% of the timeg.",
      "27% of the time.",
      "50% of the time.",
      "81% of the time. "
    ]
  },
  {
    num: 3,
    question: "If you’re struggling to come up with a secure password, you should:",
    answer: "Use a password generator.",
    options: [
      "Use a password generator.",
      "Use your favorite song.",
      "Use a pattern of keys such as ASDFG on your keyboard.",
      "Ask a stranger for his wife's date of birth.",
    ]
  },
];