var questions = [{
    num: 1,
    question: "Which of the following attacks requires a carrier file to self-replicate?",
    answer: "Virus.",
    options: [
        "Trojan.",
      "Worm.",
      "Virus.",
      "Spam."
    ]
  },
  {
    num: 2,
    question: "_____ is a type of malware that takes your data hostage until you pay a fee to release it.",
    answer: "Ransomware.",
    options: [
      "Ransomware.",
      "Phishing software.",
      "Hacking software.",
      "Kidnapping software."
    ]
  },
  {
    num: 3,
    question: "Local backup files – saved on your computer – will protect your data from being lost in a ransomware attack. True or False?",
    answer: "False.",
    options: [
      "True.",
      "False.",
    ]
  },
];